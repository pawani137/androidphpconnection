package com.example.ex10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button _btnReg,_btnLogin;
    EditText _txtname,_txtadd, _txtemail,_txtuser,_txtpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _btnLogin = (Button)findViewById(R.id.btnLogin);
        _btnReg = (Button) findViewById(R.id.btnReg);
        _txtname = (EditText)findViewById(R.id.name);
        _txtadd = (EditText)findViewById(R.id.address);
        _txtemail = (EditText)findViewById(R.id.email);
        _txtuser = (EditText)findViewById(R.id.username);
        _txtpass = (EditText)findViewById(R.id.password);

        _btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = _txtname.getText().toString();
                String address = _txtadd.getText().toString();
                String email = _txtemail.getText().toString();
                String username = _txtuser.getText().toString();
                String password = _txtpass.getText().toString();
                String type = "reg";
                BackgroundTask backgroundTask = new BackgroundTask(getApplicationContext());
                backgroundTask.execute(type,name,address,email,username,password);

            }
        });
    }
}